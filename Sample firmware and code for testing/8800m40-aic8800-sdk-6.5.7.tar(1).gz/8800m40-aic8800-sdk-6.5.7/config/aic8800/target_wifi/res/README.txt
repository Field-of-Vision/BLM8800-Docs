# download fmacfw*.bin into flash
x 81bc000 40000
