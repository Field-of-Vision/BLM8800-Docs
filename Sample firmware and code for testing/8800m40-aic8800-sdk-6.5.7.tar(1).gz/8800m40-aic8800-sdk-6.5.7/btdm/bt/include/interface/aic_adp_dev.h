#ifndef AICADPDEV
#define AICADPDEV


enum BT_LINK_NUM_T{
    LINK_1 = 0,
    LINK_2,
    LINK_MAX
};


#endif
