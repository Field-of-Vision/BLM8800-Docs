#include "hw_cfg.h"
#include <string.h>
#include <stdint.h>
#include "gpio_api.h"

void hw_cfg_init(void)
{

}
